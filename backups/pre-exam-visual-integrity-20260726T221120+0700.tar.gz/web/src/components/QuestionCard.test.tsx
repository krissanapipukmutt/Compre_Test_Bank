import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { academicData } from "../data";
import { presentQuestion } from "../engine";
import { QuestionCard } from "./QuestionCard";

const scoreable = presentQuestion(
  academicData.questions.find(
    (question) =>
      question.answer_status === "verified_from_course_material" &&
      !question.requires_human_review,
  )!,
  "test",
  false,
);
const review = presentQuestion(
  academicData.questions.find(
    (question) => question.answer_status === "unresolvable_question",
  )!,
  "test",
  false,
);
const probability = presentQuestion(
  academicData.questions.find(
    (question) => question.answer_status === "probabilistic_recommendation",
  )!,
  "test",
  false,
);
const external = presentQuestion(
  academicData.questions.find(
    (question) => question.answer_status === "verified_from_external_source",
  )!,
  "test",
  false,
);

describe("QuestionCard", () => {
  it("renders Thai and seals answers until submission", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const { rerender } = render(
      <QuestionCard
        bookmarked={false}
        onBookmark={vi.fn()}
        onChange={onChange}
        question={scoreable}
        reveal={false}
        selectedChoiceIds={[]}
      />,
    );
    expect(screen.getByText(scoreable.question_th)).toBeInTheDocument();
    expect(screen.queryByText(scoreable.explanation_en)).not.toBeInTheDocument();
    expect(
      screen.queryByText(/Verified from course materials/),
    ).not.toBeInTheDocument();
    await user.click(screen.getAllByRole("radio")[0]!);
    expect(onChange).toHaveBeenCalledWith([scoreable.choices[0]!.choice_id]);

    rerender(
      <QuestionCard
        bookmarked={false}
        onBookmark={vi.fn()}
        onChange={onChange}
        question={scoreable}
        reveal
        selectedChoiceIds={[scoreable.correct_answer as string]}
      />,
    );
    expect(screen.getAllByText(scoreable.explanation_en).length).toBeGreaterThan(0);
    expect(screen.getByText(/Correct · ถูกต้อง/)).toBeInTheDocument();
  });

  it("keeps unresolved status sealed until review", () => {
    const { rerender } = render(
      <QuestionCard
        bookmarked={false}
        onBookmark={vi.fn()}
        onChange={vi.fn()}
        question={review}
        reveal={false}
        selectedChoiceIds={[]}
      />,
    );
    expect(
      screen.queryByText(/Answer remains unresolved/),
    ).not.toBeInTheDocument();
    expect(review.correct_answer).toBeNull();
    expect(screen.queryByText(review.explanation_en)).not.toBeInTheDocument();

    rerender(
      <QuestionCard
        bookmarked={false}
        onBookmark={vi.fn()}
        onChange={vi.fn()}
        question={review}
        reveal
        selectedChoiceIds={[]}
      />,
    );
    expect(screen.getAllByText(/Answer remains unresolved/).length).toBeGreaterThan(0);
  });

  it("shows the exact probability warning and full distribution only after reveal", () => {
    const { rerender } = render(
      <QuestionCard
        bookmarked={false}
        onBookmark={vi.fn()}
        onChange={vi.fn()}
        question={probability}
        reveal={false}
        selectedChoiceIds={[]}
      />,
    );
    expect(
      screen.queryByText(probability.probability_warning_en!),
    ).not.toBeInTheDocument();

    rerender(
      <QuestionCard
        bookmarked={false}
        onBookmark={vi.fn()}
        onChange={vi.fn()}
        question={probability}
        reveal
        selectedChoiceIds={[probability.final_answer as string]}
      />,
    );
    expect(
      screen.getAllByText(probability.probability_warning_en!).length,
    ).toBeGreaterThan(0);
    expect(screen.getByText(/Recommended answer:/)).toBeInTheDocument();
    for (const item of probability.probability_distribution) {
      expect(
        screen.getAllByText(
          new RegExp(`${item.probability_percentage}%$`),
        ).length,
      ).toBeGreaterThan(0);
    }
  });

  it("shows a descriptive authoritative-source link only after reveal", () => {
    const { rerender } = render(
      <QuestionCard
        bookmarked={false}
        onBookmark={vi.fn()}
        onChange={vi.fn()}
        question={external}
        reveal={false}
        selectedChoiceIds={[]}
      />,
    );
    expect(
      screen.queryByText(/Verified from external sources/),
    ).not.toBeInTheDocument();

    rerender(
      <QuestionCard
        bookmarked={false}
        onBookmark={vi.fn()}
        onChange={vi.fn()}
        question={external}
        reveal
        selectedChoiceIds={[external.final_answer as string]}
      />,
    );
    expect(
      screen.getByText(/Verified from external sources/),
    ).toBeInTheDocument();
    expect(screen.getAllByRole("link").some((link) => Boolean(link.textContent?.trim()))).toBe(true);
  });
});
